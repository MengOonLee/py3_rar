# Copyright Contributors to the Pyro project.
# SPDX-License-Identifier: Apache-2.0

from .test_svi import *  # noqa F401
